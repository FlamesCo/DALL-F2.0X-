 -> Started on 5.19.22
 - Forked Style-GAN NADA
 --
 V1.0X [C] - Haltmann AGI
 